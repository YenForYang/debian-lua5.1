#ifndef _LUA_DEB_MULTIARCH_
#define _LUA_DEB_MULTIARCH_
#define DEB_HOST_MULTIARCH "x86_64-linux-gnu"
#endif
